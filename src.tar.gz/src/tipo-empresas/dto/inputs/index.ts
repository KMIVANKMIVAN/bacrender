export { CreateTipoEmpresaInput } from './create-tipo-empresas.input';
export { UpdateTipoEmpresaInput } from './update-tipo-empresas.input';
