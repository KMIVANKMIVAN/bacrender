export { UpdateSucursalInput } from './update-sucursales.input';
export { CreateSucursalInput } from './create-sucursales.input';
