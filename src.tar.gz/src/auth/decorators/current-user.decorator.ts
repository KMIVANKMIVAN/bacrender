import {
  createParamDecorator,
  ExecutionContext,
  ForbiddenException,
  InternalServerErrorException,
} from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import { ValidRoles } from '../enums/valid-roles.enum';
import { Usuario } from '../../usuarios/entities/usuario.entity';

export const CurrentUser = createParamDecorator(

  (roles: ValidRoles[] = [], context: ExecutionContext) => {
    const ctx = GqlExecutionContext.create(context);
    const usuario: Usuario = ctx.getContext().req.user;

    if (!usuario) {
      throw new InternalServerErrorException(
        `Ningun usuario dentro de la solicitud: asegúrese de que usamos AuthGuard`,
      );
    }

    if (roles.length === 0) return usuario;

    let rolBd: string = '';

    if (usuario.rol.id === 4) {
      rolBd = 'Aministrador';
    }

    if (usuario.rol.id === 2) {
      rolBd = 'Agente';
    }

    if (usuario.rol.id === 3) {
      rolBd = 'Ejecutivo';
    }

    if (roles.includes(rolBd as ValidRoles)) {
      return usuario;
    }

    throw new ForbiddenException(
      `Usuario ${usuario.nombres} el rol no es valido [${roles}]`,
    );
  },
);
