export { UpdateRolInput } from './update-roles.input';
export { CreateRolInput } from './create-roles.input';
